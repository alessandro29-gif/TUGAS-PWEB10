<?php
include("config.php");
$halaman = "list";
$judul_hero = "Pendaftar";
$teks_hero = "Daftar siswa yang sudah mendaftar. Data bisa diubah atau dihapus dari tabel di bawah.";
include("header.php");

$sql = "SELECT * FROM calon_siswa ORDER BY id ASC";
$query = mysqli_query($db, $sql);
$jumlah = mysqli_num_rows($query);
$no = 0;
?>
<section class="bagian" style="padding-top:8px">
<div class="container">
<?php if( isset($_GET['status']) ){
if( $_GET['status'] == 'sukses-edit' ){ ?>
<p class="kotak-info" role="status">Data siswa berhasil diubah.</p>
<?php } elseif( $_GET['status'] == 'sukses-hapus' ){ ?>
<p class="kotak-info" role="status">Data siswa berhasil dihapus.</p>
<?php } elseif( $_GET['status'] == 'tidak-ada' ){ ?>
<p class="kotak-info galat" role="alert">Data siswa tidak ditemukan.</p>
<?php } elseif( $_GET['status'] == 'gagal' ){ ?>
<p class="kotak-info galat" role="alert">Proses gagal. Coba lagi ya.</p>
<?php }
} ?>
<div class="alat-bar">
<a class="btn-sekunder" href="form-daftar.php">Tambah baru</a>
</div>
<p class="jumlah-hasil" aria-live="polite"><?php echo $jumlah; ?> siswa sudah mendaftar</p>
<div class="tabel-bungkus">
<?php if( $jumlah == 0 ){ ?>
<div class="kosong"><p>Belum ada siswa yang mendaftar.</p></div>
<?php } else { ?>
<div class="table-responsive">
<table class="table tabel-anggota">
<thead><tr><th scope="col">No</th><th scope="col">Nama</th><th scope="col">Alamat</th><th scope="col">Jenis Kelamin</th><th scope="col">Agama</th><th scope="col">Sekolah Asal</th><th scope="col">Tindakan</th></tr></thead>
<tbody>
<?php while( $siswa = mysqli_fetch_array($query) ){
$no++; ?>
<tr>
<td><?php echo $no; ?></td>
<td class="nama"><?php echo htmlspecialchars($siswa['nama']); ?></td>
<td><?php echo htmlspecialchars($siswa['alamat']); ?></td>
<td><span class="lencana <?php echo ($siswa['jenis_kelamin'] == 'laki-laki') ? 'lencana-dosen' : 'lencana-mahasiswa'; ?>"><?php echo htmlspecialchars(ucfirst($siswa['jenis_kelamin'])); ?></span></td>
<td><?php echo htmlspecialchars($siswa['agama']); ?></td>
<td><?php echo htmlspecialchars($siswa['sekolah_asal']); ?></td>
<td class="aksi-baris">
<a class="tombol-kecil" href="form-edit.php?id=<?php echo (int)$siswa['id']; ?>" style="text-decoration:none">Edit</a>
<form action="hapus.php" method="POST" style="display:inline" onsubmit="return confirm('Yakin mau hapus data <?php echo htmlspecialchars(addslashes($siswa['nama']), ENT_QUOTES); ?>?');">
<input type="hidden" name="id" value="<?php echo (int)$siswa['id']; ?>">
<button type="submit" class="tombol-kecil hapus">Hapus</button>
</form>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
<?php } ?>
</div>
</div>
</section>
<?php include("footer.php"); ?>
