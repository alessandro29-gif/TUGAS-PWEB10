</main>
<footer class="site-footer">
<div class="container">
<div class="row">
<div class="col-sm-4">
<p class="brand-teks">SMK Coding</p>
</div>
<div class="col-sm-4">
<h4>Halaman</h4>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="form-daftar.php">Daftar Baru</a></li>
<li><a href="list-siswa.php">Pendaftar</a></li>
</ul>
</div>
<div class="col-sm-4">
<h4>Kontak</h4>
<p style="margin-bottom:8px">SMK Coding<br>Surabaya, Jawa Timur</p>
</div>
</div>
<p class="hak-cipta">&copy; 2026 SMK Coding. Tugas PHP dan MySQL &ndash; Alessandro Almaz Filemon (5025251095).</p>
</div>
</footer>
<script>
var tombol = document.getElementById("nav-toggle");
var menu = document.getElementById("menu-utama");
tombol.addEventListener("click", function(){
var buka = menu.classList.toggle("terbuka");
tombol.setAttribute("aria-expanded", buka ? "true" : "false");
});
</script>
</body>
</html>
