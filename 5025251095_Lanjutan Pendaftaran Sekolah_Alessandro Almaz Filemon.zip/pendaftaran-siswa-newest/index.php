<?php
$halaman = "index";
$hero_besar = true;
$judul_hero = "SMK Coding";
$teks_hero = "Pendaftaran siswa baru SMK Coding. Isi formulir sekali, data kamu langsung tersimpan ke database dan bisa dilihat di daftar pendaftar.";
include("header.php");
?>
<section class="bagian" style="padding-top:8px">
<div class="container">
<?php if( isset($_GET['status']) && $_GET['status'] == 'sukses' ){ ?>
<p class="kotak-info" role="status">Pendaftaran berhasil! Data kamu sudah tersimpan.</p>
<?php } elseif( isset($_GET['status']) && $_GET['status'] == 'gagal' ){ ?>
<p class="kotak-info galat" role="alert">Pendaftaran gagal. Coba lagi ya.</p>
<?php } ?>
<h2>Menu</h2>
<div class="baris-kartu">
<div class="col-sm-6"><a class="kartu-hero" href="form-daftar.php"><div><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span><h3>Daftar Baru</h3><p>Isi formulir pendaftaran siswa baru.</p></div><span class="tuju">Buka Formulir</span></a></div>
<div class="col-sm-6"><a class="kartu-hero" href="list-siswa.php"><div><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span><h3>Pendaftar</h3><p>Lihat siswa yang sudah mendaftar, lalu ubah atau hapus datanya.</p></div><span class="tuju">Lihat Daftar</span></a></div>
</div>
</div>
</section>
<?php include("footer.php"); ?>
