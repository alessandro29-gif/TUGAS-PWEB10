<?php
include("config.php");

if( !isset($_POST['simpan']) ){
header('Location: list-siswa.php');
exit;
}

$id = (int)$_POST['id'];
$nama = trim($_POST['nama']);
$alamat = trim($_POST['alamat']);
$jk = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : "";
$agama = isset($_POST['agama']) ? $_POST['agama'] : "";
$sekolah = trim($_POST['sekolah_asal']);

$daftar_jk = array("laki-laki", "perempuan");
$daftar_agama = array("Islam", "Kristen", "Katolik", "Hindu", "Buddha", "Konghucu");

if( $nama == "" || $alamat == "" || $sekolah == "" || !in_array($jk, $daftar_jk) || !in_array($agama, $daftar_agama) ){
header('Location: form-edit.php?id=' . $id . '&status=gagal');
exit;
}

$sql = "UPDATE calon_siswa SET nama = ?, alamat = ?, jenis_kelamin = ?, agama = ?, sekolah_asal = ? WHERE id = ?";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_bind_param($stmt, "sssssi", $nama, $alamat, $jk, $agama, $sekolah, $id);

if( mysqli_stmt_execute($stmt) ){
header('Location: list-siswa.php?status=sukses-edit');
} else {
header('Location: list-siswa.php?status=gagal');
}
exit;
?>
