<?php
$server = "localhost";
$user = "root";
$password = "";
$nama_database = "pendaftaran_siswa_newest";

$db = mysqli_connect($server, $user, $password, $nama_database);

if( !$db ){
die("Gagal terhubung dengan database: " . mysqli_connect_error());
}

mysqli_set_charset($db, "utf8mb4");
?>
