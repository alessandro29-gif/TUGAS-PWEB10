<?php
include("config.php");

if( $_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_POST['id']) ){
header('Location: list-siswa.php');
exit;
}

$id = (int)$_POST['id'];

$sql = "DELETE FROM calon_siswa WHERE id = ?";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);

if( mysqli_stmt_execute($stmt) ){
header('Location: list-siswa.php?status=sukses-hapus');
} else {
header('Location: list-siswa.php?status=gagal');
}
exit;
?>
