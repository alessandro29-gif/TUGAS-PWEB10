<?php
if( !isset($halaman) ){ $halaman = ""; }
if( !isset($judul_hero) ){ $judul_hero = "SMK Coding"; }
if( !isset($teks_hero) ){ $teks_hero = ""; }
if( !isset($hero_besar) ){ $hero_besar = false; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#238689">
<title><?php echo htmlspecialchars($judul_hero); ?> - Pendaftaran Siswa Baru SMK Coding</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<a class="sr-only sr-only-focusable" href="#konten">Lewati ke konten utama</a>
<header class="site-header">
<div class="container">
<a class="brand-teks" href="index.php" aria-label="SMK Coding, ke halaman utama">SMK Coding</a>
<button type="button" class="nav-toggle" id="nav-toggle" aria-controls="menu-utama" aria-expanded="false" aria-label="Buka menu">
<span></span><span></span><span></span>
</button>
<nav aria-label="Menu utama">
<ul class="menu-utama" id="menu-utama">
<li<?php if($halaman == "index"){ echo ' class="aktif"'; } ?>><a href="index.php">Home</a></li>
<li<?php if($halaman == "daftar"){ echo ' class="aktif"'; } ?>><a href="form-daftar.php">Daftar Baru</a></li>
<li<?php if($halaman == "list"){ echo ' class="aktif"'; } ?>><a href="list-siswa.php">Pendaftar</a></li>
</ul>
</nav>
</div>
</header>
<main class="konten" id="konten">
<section class="hero-polos<?php if(!$hero_besar){ echo ' hero-kecil'; } ?>">
<div class="container">
<h1 class="hero-judul"><?php echo htmlspecialchars($judul_hero); ?></h1>
<?php if($teks_hero != ""){ ?>
<p class="hero-teks"><?php echo htmlspecialchars($teks_hero); ?></p>
<?php } ?>
</div>
</section>
