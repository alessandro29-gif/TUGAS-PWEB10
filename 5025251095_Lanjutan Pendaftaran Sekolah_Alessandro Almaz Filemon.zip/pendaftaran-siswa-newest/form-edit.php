<?php
include("config.php");

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$sql = "SELECT * FROM calon_siswa WHERE id = ?";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);
$siswa = mysqli_fetch_assoc($hasil);

if( !$siswa ){
header('Location: list-siswa.php?status=tidak-ada');
exit;
}

$daftar_agama = array("Islam", "Kristen", "Katolik", "Hindu", "Buddha", "Konghucu");

$halaman = "list";
$judul_hero = "Edit Data";
$teks_hero = "Ubah data siswa lalu simpan. Semua kolom wajib diisi.";
include("header.php");
?>
<section class="bagian" style="padding-top:8px">
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<?php if( isset($_GET['status']) && $_GET['status'] == 'gagal' ){ ?>
<p class="kotak-info galat" role="alert">Data belum lengkap atau tidak valid. Periksa lagi isiannya.</p>
<?php } ?>
<div class="kartu-form">
<form action="proses-edit.php" method="POST" aria-label="Formulir edit data siswa">
<input type="hidden" name="id" value="<?php echo (int)$siswa['id']; ?>">
<div class="form-group">
<label for="nama">Nama</label>
<input type="text" class="form-control" id="nama" name="nama" maxlength="64" value="<?php echo htmlspecialchars($siswa['nama']); ?>" required>
</div>
<div class="form-group">
<label for="alamat">Alamat</label>
<textarea class="form-control" id="alamat" name="alamat" maxlength="255" required><?php echo htmlspecialchars($siswa['alamat']); ?></textarea>
</div>
<div class="form-group">
<span class="judul-isian" id="label-jk">Jenis Kelamin</span>
<div class="pilihan-jenis" role="radiogroup" aria-labelledby="label-jk">
<label><input type="radio" name="jenis_kelamin" value="laki-laki" <?php if($siswa['jenis_kelamin'] == 'laki-laki'){ echo 'checked'; } ?> required><span>Laki-laki</span></label>
<label><input type="radio" name="jenis_kelamin" value="perempuan" <?php if($siswa['jenis_kelamin'] == 'perempuan'){ echo 'checked'; } ?>><span>Perempuan</span></label>
</div>
</div>
<div class="form-group">
<label for="agama">Agama</label>
<select class="form-control" id="agama" name="agama" required>
<?php foreach( $daftar_agama as $a ){ ?>
<option value="<?php echo $a; ?>"<?php if($siswa['agama'] == $a){ echo ' selected'; } ?>><?php echo $a; ?></option>
<?php } ?>
</select>
</div>
<div class="form-group">
<label for="sekolah_asal">Sekolah Asal</label>
<input type="text" class="form-control" id="sekolah_asal" name="sekolah_asal" maxlength="64" value="<?php echo htmlspecialchars($siswa['sekolah_asal']); ?>" required>
</div>
<button type="submit" name="simpan" value="Simpan" class="btn-utama" style="font-size:22px">Simpan</button>
<a class="btn-sekunder" href="list-siswa.php" style="margin-left:6px">Batal</a>
</form>
</div>
</div>
</div>
</div>
</section>
<?php include("footer.php"); ?>
