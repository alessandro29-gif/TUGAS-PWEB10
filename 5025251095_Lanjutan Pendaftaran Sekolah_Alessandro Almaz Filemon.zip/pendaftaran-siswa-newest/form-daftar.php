<?php
$halaman = "daftar";
$judul_hero = "Formulir Pendaftaran";
$teks_hero = "Lengkapi data berikut untuk mendaftar sebagai siswa baru SMK Coding. Semua kolom wajib diisi.";
include("header.php");
?>
<section class="bagian" style="padding-top:8px">
<div class="container">
<div class="row">
<div class="col-md-8 col-md-offset-2">
<?php if( isset($_GET['status']) && $_GET['status'] == 'gagal' ){ ?>
<p class="kotak-info galat" role="alert">Data belum lengkap atau tidak valid. Periksa lagi isiannya.</p>
<?php } ?>
<div class="kartu-form">
<form action="proses-pendaftaran.php" method="POST" aria-label="Formulir pendaftaran siswa baru">
<div class="form-group">
<label for="nama">Nama</label>
<input type="text" class="form-control" id="nama" name="nama" maxlength="64" placeholder="Nama lengkap" required>
</div>
<div class="form-group">
<label for="alamat">Alamat</label>
<textarea class="form-control" id="alamat" name="alamat" maxlength="255" placeholder="Alamat tempat tinggal" required></textarea>
</div>
<div class="form-group">
<span class="judul-isian" id="label-jk">Jenis Kelamin</span>
<div class="pilihan-jenis" role="radiogroup" aria-labelledby="label-jk">
<label><input type="radio" name="jenis_kelamin" value="laki-laki" required><span>Laki-laki</span></label>
<label><input type="radio" name="jenis_kelamin" value="perempuan"><span>Perempuan</span></label>
</div>
</div>
<div class="form-group">
<label for="agama">Agama</label>
<select class="form-control" id="agama" name="agama" required>
<option value="">Pilih agama</option>
<option value="Islam">Islam</option>
<option value="Kristen">Kristen</option>
<option value="Katolik">Katolik</option>
<option value="Hindu">Hindu</option>
<option value="Buddha">Buddha</option>
<option value="Konghucu">Konghucu</option>
</select>
</div>
<div class="form-group">
<label for="sekolah_asal">Sekolah Asal</label>
<input type="text" class="form-control" id="sekolah_asal" name="sekolah_asal" maxlength="64" placeholder="Contoh: SMP Negeri 1 Surabaya" required>
</div>
<button type="submit" name="daftar" value="Daftar" class="btn-utama" style="font-size:22px">Daftar</button>
<a class="btn-sekunder" href="index.php" style="margin-left:6px">Batal</a>
</form>
</div>
</div>
</div>
</div>
</section>
<?php include("footer.php"); ?>
