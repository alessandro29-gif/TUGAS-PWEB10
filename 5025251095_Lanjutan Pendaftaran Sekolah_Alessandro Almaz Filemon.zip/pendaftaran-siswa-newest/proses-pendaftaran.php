<?php
include("config.php");

if( !isset($_POST['daftar']) ){
header('Location: index.php');
exit;
}

$nama = trim($_POST['nama']);
$alamat = trim($_POST['alamat']);
$jk = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : "";
$agama = isset($_POST['agama']) ? $_POST['agama'] : "";
$sekolah = trim($_POST['sekolah_asal']);

$daftar_jk = array("laki-laki", "perempuan");
$daftar_agama = array("Islam", "Kristen", "Katolik", "Hindu", "Buddha", "Konghucu");

if( $nama == "" || $alamat == "" || $sekolah == "" || !in_array($jk, $daftar_jk) || !in_array($agama, $daftar_agama) ){
header('Location: form-daftar.php?status=gagal');
exit;
}

$sql = "INSERT INTO calon_siswa (nama, alamat, jenis_kelamin, agama, sekolah_asal) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($db, $sql);
mysqli_stmt_bind_param($stmt, "sssss", $nama, $alamat, $jk, $agama, $sekolah);

if( mysqli_stmt_execute($stmt) ){
header('Location: index.php?status=sukses');
} else {
header('Location: index.php?status=gagal');
}
exit;
?>
